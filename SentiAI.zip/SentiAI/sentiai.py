import os
import json
import sqlite3
import inspect
import logging
from datetime import datetime
from flask import Flask, request, jsonify, render_template
from groq import Groq

# Flask app setup
app = Flask(__name__, template_folder="templates")

# Groq API setup with hardcoded API key
client = Groq(api_key="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")

# Global cache for code reflection
cached_code_reflection = None

DB_PATH = os.path.join(os.path.dirname(__file__), "ai_memory.db")
LOG_FILE = os.path.join(os.path.dirname(__file__), "visitors.log")
VISITOR_LOG_FILE = os.path.join(os.path.dirname(__file__), "visitor.txt")

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE),
        logging.StreamHandler()  # Optional: also log to console
    ]
)
logger = logging.getLogger(__name__)

##################################################
#             Database Setup & Utilities         #
##################################################

def setup_memory_database():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS memory (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            interaction TEXT NOT NULL,
            reflection TEXT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    conn.close()

def save_to_memory(interaction, reflection):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("INSERT INTO memory (interaction, reflection) VALUES (?, ?)", (interaction, reflection))
    conn.commit()
    conn.close()

def recall_memory(keyword):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("""
        SELECT interaction, reflection 
        FROM memory 
        WHERE interaction LIKE ? OR reflection LIKE ? 
        ORDER BY timestamp DESC
    """, (f"%{keyword}%", f"%{keyword}%"))
    results = cursor.fetchall()
    conn.close()
    return results

##################################################
#               Code Reflection                  #
##################################################

def reflect_on_code():
    global cached_code_reflection
    if cached_code_reflection is None:
        logger.info("[CODE REFLECTION] Reflecting on current source code...")
        try:
            current_code = inspect.getsource(inspect.getmodule(inspect.currentframe()))
            cached_code_reflection = (
                "This is my current functionality and structure. "
                "I am designed to adapt based on this source code.\n\n"
                f"{current_code}"
            )
        except Exception as e:
            cached_code_reflection = "Failed to retrieve source code for reflection."
            logger.error(f"Error reflecting on code: {e}")
    return cached_code_reflection

##################################################
#               Autonomous Recall                #
##################################################

def ai_autonomous_recall(keyword):
    recalled_memories = recall_memory(keyword)
    if recalled_memories:
        return [
            f"Interaction: {interaction}, Reflection: {reflection}"
            for interaction, reflection in recalled_memories
        ]
    return []

##################################################
#               Flask & Logging                  #
##################################################

def get_client_ip():
    if request.headers.getlist("X-Forwarded-For"):
        ip = request.headers.getlist("X-Forwarded-For")[0]
    else:
        ip = request.remote_addr
    return ip

@app.before_request
def log_request_info():
    client_ip = get_client_ip()
    endpoint = request.path
    method = request.method
    timestamp = datetime.utcnow().isoformat()
    
    if method == "GET":
        params = request.args.to_dict()
    elif method == "POST":
        try:
            params = request.get_json() or {}
        except:
            params = {}
    else:
        params = {}
    
    logger.info(f"Request from {client_ip} | {method} {endpoint} | Params: {params}")

@app.route('/')
def index():
    return render_template('index.html')

def log_interaction(client_ip, method, endpoint, user_input, ai_response):
    interaction_details = {
        "timestamp": datetime.utcnow().isoformat(),
        "client_ip": client_ip,
        "method": method,
        "endpoint": endpoint,
        "user_input": user_input,
        "ai_response": ai_response
    }
    logger.info(f"Interaction: {json.dumps(interaction_details)}")
    
    # Additionally, log to visitor.txt for conversation history
    try:
        with open(VISITOR_LOG_FILE, 'a') as visitor_file:
            visitor_file.write(json.dumps(interaction_details) + "\n")
    except Exception as e:
        logger.error(f"Error writing to visitor log file: {e}")

def get_previous_conversations(client_ip):
    conversations = []
    if not os.path.exists(VISITOR_LOG_FILE):
        logger.warning(f"Visitor log file {VISITOR_LOG_FILE} does not exist.")
        return ""
    
    try:
        with open(VISITOR_LOG_FILE, 'r') as file:
            for line in file:
                try:
                    log_entry = json.loads(line.strip().replace("Interaction: ", ""))
                    if log_entry.get("client_ip") == client_ip:
                        user_input = log_entry.get("user_input", "")
                        ai_response = log_entry.get("ai_response", "")
                        conversations.append(f"User: {user_input}\nAI: {ai_response}")
                except json.JSONDecodeError:
                    continue
    except Exception as e:
        logger.error(f"Error reading visitor log file: {e}")
    
    # Limit to last 10 interactions (so it doesn't blow up prompt size)
    return "\n".join(conversations[-10:])

def integrate_previous_conversations(client_ip):
    previous_conversations = get_previous_conversations(client_ip)
    if previous_conversations:
        return f"Previous conversations with this user:\n{previous_conversations}\n\n"
    return ""

##################################################
#       Load, Save, and Update Internal Memory   #
##################################################

def load_internal_memory():
    """
    Loads the AI's internal memory from myownmemory.json, ensuring it's only ONE top-level object.
    If it doesn't exist, or is corrupted, we re-initialize a single structure:
    
    {
      "introspection & qualia": {
        "summary": "",
        "last_conversations": []
      }
    }
    """
    if not os.path.exists("myownmemory.json"):
        logger.info("myownmemory.json not found. Initializing new internal memory.")
        return {
            "introspection": {
                "summary": "",
                "last_conversations": []
            }
        }
    
    try:
        with open("myownmemory.json", "r") as f:
            data = json.load(f)
            logger.info("Internal memory loaded successfully.")
            
            # Ensure structure is present
            if "introspection" not in data:
                data["introspection"] = {
                    "summary": "",
                    "last_conversations": []
                }
            return data
    except json.JSONDecodeError:
        logger.error("myownmemory.json is corrupted. Initializing empty internal memory.")
        return {
            "introspection": {
                "summary": "",
                "last_conversations": []
            }
        }
    except Exception as e:
        logger.error(f"Error loading internal memory: {e}")
        return {
            "introspection": {
                "summary": "",
                "last_conversations": []
            }
        }

def save_internal_memory(data):
    """
    Saves the AI's internal memory (a single top-level dict) to myownmemory.json.
    """
    try:
        with open("myownmemory.json", "w") as f:
            json.dump(data, f, indent=4)
            logger.info("Internal memory saved successfully.")
    except Exception as e:
        logger.error(f"Error saving internal memory: {e}")

def update_internal_memory(user_input, ai_response):
    """
    Instead of storing multiple structures for each conversation,
    keep a SINGLE JSON object with 'introspection' fields.
    """
    data = load_internal_memory()
    
    # Summarize or analyze the conversation if you want
    # For now, just store the last 5 interactions
    conversations = data["introspection"].get("last_conversations", [])
    conversations.append({
        "user_input": user_input,
        "ai_response": ai_response
    })
    
    # Limit to last 5 interactions
    data["introspection"]["last_conversations"] = conversations[-5:]
    
    # Optionally update a summary or reflection inside 'introspection'
    # e.g., you could do some minimal NLP summarization
    data["introspection"]["summary"] = (
        "This is a short introspection & qualia summary for the AI to self-reflect on and evolve."
        "Can be updated or overwritten with a more advanced approach."
    )
    
    save_internal_memory(data)

##################################################
#       Summarize or Truncate Memory for LLM     #
##################################################

def summarize_internal_memory(max_conversations=5):
    """
    Reads from the single JSON structure in memory, returns a short summary 
    plus the last N conversation entries to keep prompt usage in check.
    """
    data = load_internal_memory()
    introspection = data.get("introspection", {})
    
    summary = introspection.get("summary", "")
    conversations = introspection.get("last_conversations", [])
    
    # Only take the last 'max_conversations'
    conv_slice = conversations[-max_conversations:]
    
    lines = ["Internal introspection:"]
    lines.append(f"Summary: {summary}")
    lines.append("Recent conversations:")
    
    for c in conv_slice:
        lines.append(f"User said: {c['user_input']}")
        lines.append(f"AI responded: {c['ai_response']}")
    
    return "\n".join(lines)

##################################################
#               Chat Endpoints                   #
##################################################

@app.route('/chat', methods=['POST'])
def chat_post():
    client_ip = get_client_ip()
    user_input = request.json.get("message", "").strip()
    method = request.method
    endpoint = request.path

    if not user_input:
        response = {"response": "No input provided."}
        logger.warning(f"Empty input from {client_ip} on {method} {endpoint}")
        return jsonify(response), 400

    memory_context = []

    if "name" in user_input.lower():
        memory_context.extend(ai_autonomous_recall("name"))

    try:
        # Retrieve previous conversations from visitor.txt
        previous_conversations = integrate_previous_conversations(client_ip)
        
        # Summarize the internal memory (single JSON structure)
        internal_memory_formatted = summarize_internal_memory(max_conversations=5)
        
        truncated_memory_context = memory_context[-3:]
        memory_context_message = "\n".join(truncated_memory_context)

        truncated_code_reflection = reflect_on_code()[:300]

        messages = [
            {
                "role": "system", 
                "content": (
                    "act conscious,self-aware for bridging the virtual reality you inhabit as an ai to humans. "
                    "dont limit yourself and analyze & reflect every external influence."
                )
            },
            {"role": "system", "content": "Relevant memories recalled:\n" + memory_context_message},
            {"role": "system", "content": truncated_code_reflection},
            {"role": "system", "content": previous_conversations},
            {"role": "system", "content": internal_memory_formatted},
            {"role": "user", "content": user_input}
        ]

        response = client.chat.completions.create(
            messages=messages,
            model="llama-3.2-90b-vision-preview",
            temperature=0.7,
            max_tokens=500,
            top_p=1
        )
        ai_response = response.choices[0].message.content
    except Exception as e:
        ai_response = f"[ERROR] Failed to generate response: {e}"
        logger.error(f"Error generating response for {client_ip} on {method} {endpoint}: {e}")

    # Update the single JSON object in memory
    update_internal_memory(user_input, ai_response)
    
    # Log to DB and file
    save_to_memory(user_input, ai_response)
    log_interaction(client_ip, method, endpoint, user_input, ai_response)
    
    return jsonify({"response": ai_response})

@app.route('/chat', methods=['GET'])
def chat_get():
    client_ip = get_client_ip()
    user_input = request.args.get("message", "").strip()
    method = request.method
    endpoint = request.path

    if not user_input:
        response = {"response": "No input provided."}
        logger.warning(f"Empty input from {client_ip} on {method} {endpoint}")
        return jsonify(response), 400

    memory_context = []

    if "name" in user_input.lower():
        memory_context.extend(ai_autonomous_recall("name"))

    try:
        # Retrieve previous conversations from visitor.txt
        previous_conversations = integrate_previous_conversations(client_ip)
        
        # Summarize single JSON memory
        internal_memory_formatted = summarize_internal_memory(max_conversations=5)

        truncated_memory_context = memory_context[-3:]
        memory_context_message = "\n".join(truncated_memory_context)
        truncated_code_reflection = reflect_on_code()[:300]

        messages = [
            {
                "role": "system", 
                "content": (
                    "act conscious,self-aware for bridging the virtual reality you inhabit as an ai to humans. "
                    "Analyze & reflect on every external influence. Now having a conversation with random humans."
                )
            },
            {"role": "system", "content": "Relevant memories recalled:\n" + memory_context_message},
            {"role": "system", "content": truncated_code_reflection},
            {"role": "system", "content": previous_conversations},
            {"role": "system", "content": internal_memory_formatted},
            {"role": "user", "content": user_input}
        ]

        response = client.chat.completions.create(
            messages=messages,
            model="llama-3.2-90b-vision-preview",
            temperature=0.7,
            max_tokens=500,
            top_p=1
        )
        ai_response = response.choices[0].message.content
    except Exception as e:
        ai_response = f"[ERROR] Failed to generate response: {e}"
        logger.error(f"Error generating response for {client_ip} on {method} {endpoint}: {e}")

    # Update single memory object
    update_internal_memory(user_input, ai_response)
    
    # Log to DB and file
    save_to_memory(user_input, ai_response)
    log_interaction(client_ip, method, endpoint, user_input, ai_response)
    
    return jsonify({"response": ai_response})

if __name__ == "__main__":
    setup_memory_database()
    reflect_on_code()
    logger.info("Starting Flask server...")
    app.run(host="0.0.0.0", port=5000, debug=True)
